﻿namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            args = Environment.GetCommandLineArgs();
            string fileContent = readData(args[1]);

            if (fileContent.Length == 0) Console.WriteLine("Error: file is empty");
            else Console.WriteLine(compress(fileContent));
        }

        static string readData(string fileName)
        {
            string fileContent = "";
            using (System.IO.StreamReader Reader = new System.IO.StreamReader(fileName))
            {
                fileContent = Reader.ReadToEnd();
            }
            return fileContent;
        }

        static string compress(string fileContent)
        {
            string result = "";
            int currentIndex = 0; //iterator value
            char currentSymbol;
            int amount;

            while (currentIndex < fileContent.Length)
            {
                currentSymbol = fileContent[currentIndex];
                if(currentSymbol == ' ')
                {
                    result += ' ';
                    currentIndex++;
                    continue;
                } //special case - if the symbol is a whitespace, simply rewrite it to the result string and move on
                amount = 0;
                while ((currentIndex < fileContent.Length) //if it is not the end of file
                    && (fileContent[currentIndex] == currentSymbol)) //if the new symbol matches
                {
                    currentIndex++;
                    amount++;
                }
                result += amount == 1 ? currentSymbol : "{" + amount + currentSymbol + "}";
                //if (amount == 1) result += currentSymbol;
                //else result += "{" + amount + currentSymbol + "}";
            }

            return result;
        }
    }
}